
const doc = document.querySelector("html");
doc.classList.remove("no-js");

if ( !!((window.CSS && window.CSS.supports) || false) ){
    if ( !!( CSS.supports("display", "grid") ) ) {
        doc.classList.remove("no-grid");
    }
    if ( !!( CSS.supports("color", "var(--var)") ) ) {
        doc.classList.remove("no-cssvar");
    }
}
