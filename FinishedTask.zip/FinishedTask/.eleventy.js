module.exports = function (eleventyConfig) {
    // eleventyConfig.setQuietMode(true);
    return {
        dir: {
            input: "views",
            output: "dist"
        },
    }
}