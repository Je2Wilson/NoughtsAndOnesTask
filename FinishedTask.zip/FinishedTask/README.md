# Dev Snowpack

Node v12.x

run `yarn install`

## Sass

from project root folder

```bash
sass.bat scss/main.scss:static/assets/css/main.css --watch
```

## Snowpack

In second terminal window, run Snowpack.

```bash
npx snowpack dev
```

That will build a dev version of Eleventy, with live reloading, and open a new window with the site.

To output a completely static self contained site, run a build - it outputs everything to `dist` folder (may need to delete old content first for true production)

```bash
npx snowpack build
```
